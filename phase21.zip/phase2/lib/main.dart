import 'package:flutter/material.dart';
import 'package:test22/login.dart';
void main() {
  runApp(const MaterialApp(
    home: LoginPage(),
    debugShowCheckedModeBanner: false,// Initialize NavBar in home screen
  ));
}